"use strict";
/*
 * MedRecall server
 * - Accounts (email + password, scrypt hashing, JWT sessions)
 * - Sync: one JSON blob of study data per user
 * - Free plan limits, Pro plan via Stripe subscription
 */
const path = require("path");
const crypto = require("crypto");
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const Stripe = require("stripe");

const {
  JWT_SECRET,
  STRIPE_SECRET_KEY,
  STRIPE_PRICE_ID,
  STRIPE_WEBHOOK_SECRET,
  APP_URL = "http://localhost:3000",
  DB_PATH = "data.db",
  PORT = 3000,
} = process.env;

if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set JWT_SECRET to a random string of at least 32 characters.");
  process.exit(1);
}

const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY) : null;
const FREE_LIMITS = { mistakes: 30, cards: 60 };
const PRO_STATUSES = new Set(["active", "trialing"]);

/* ---------- database ---------- */
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    pw_salt TEXT NOT NULL,
    pw_hash TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    stripe_customer_id TEXT,
    plan_status TEXT NOT NULL DEFAULT 'free'
  );
  CREATE TABLE IF NOT EXISTS states (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    data TEXT NOT NULL,
    updated_at INTEGER NOT NULL
  );
`);
db.pragma("foreign_keys = ON");

const q = {
  userByEmail: db.prepare("SELECT * FROM users WHERE email = ?"),
  userById: db.prepare("SELECT * FROM users WHERE id = ?"),
  userByCustomer: db.prepare("SELECT * FROM users WHERE stripe_customer_id = ?"),
  insertUser: db.prepare("INSERT INTO users (email, pw_salt, pw_hash, created_at) VALUES (?, ?, ?, ?)"),
  setCustomer: db.prepare("UPDATE users SET stripe_customer_id = ? WHERE id = ?"),
  setPlan: db.prepare("UPDATE users SET plan_status = ? WHERE id = ?"),
  getState: db.prepare("SELECT data, updated_at FROM states WHERE user_id = ?"),
  putState: db.prepare(
    "INSERT INTO states (user_id, data, updated_at) VALUES (?, ?, ?) " +
      "ON CONFLICT(user_id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at"
  ),
  deleteUser: db.prepare("DELETE FROM users WHERE id = ?"),
};

/* ---------- helpers ---------- */
function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString("hex");
}
function verifyPassword(password, salt, expectedHex) {
  const got = Buffer.from(hashPassword(password, salt), "hex");
  const want = Buffer.from(expectedHex, "hex");
  return got.length === want.length && crypto.timingSafeEqual(got, want);
}
function isPro(user) {
  return PRO_STATUSES.has(user.plan_status);
}
function sign(user) {
  return jwt.sign({ uid: user.id }, JWT_SECRET, { expiresIn: "60d" });
}
function validEmail(e) {
  return typeof e === "string" && e.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
}
function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  try {
    const { uid } = jwt.verify(token, JWT_SECRET);
    const user = q.userById.get(uid);
    if (!user) throw new Error("no user");
    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: "Please sign in again." });
  }
}
/* Keep only the fields the app uses, with sane sizes. */
function cleanState(data) {
  if (!data || typeof data !== "object") return null;
  const str = (v, n) => (typeof v === "string" ? v.slice(0, n) : "");
  const num = (v) => (Number.isFinite(v) ? v : 0);
  const minutes = {};
  for (const [k, v] of Object.entries(data.minutes || {})) {
    if (/^\d{4}-\d{2}-\d{2}$/.test(k)) minutes[k] = Math.max(0, Math.min(num(v), 1440));
  }
  const item = (x, extra) => ({
    id: str(x.id, 40),
    q: str(x.q, 4000),
    a: str(x.a, 4000),
    box: Math.max(0, Math.min(num(x.box), 5)),
    due: /^\d{4}-\d{2}-\d{2}$/.test(x.due) ? x.due : "1970-01-01",
    sample: x.sample ? true : undefined,
    ...extra(x),
  });
  const list = (arr, extra) =>
    (Array.isArray(arr) ? arr : []).filter((x) => x && typeof x === "object" && x.id && x.q).map((x) => item(x, extra));
  return {
    minutes,
    mistakes: list(data.mistakes, (x) => ({ topic: str(x.topic, 80) })),
    cards: list(data.cards, (x) => ({ tag: str(x.tag, 80) })),
  };
}

/* ---------- app ---------- */
const app = express();
app.set("trust proxy", 1);
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["https://fonts.gstatic.com"],
        connectSrc: ["'self'"],
        imgSrc: ["'self'", "data:"],
        frameAncestors: ["'none'"],
        upgradeInsecureRequests: process.env.NODE_ENV === "production" ? [] : null,
      },
    },
  })
);

/* Stripe webhook needs the raw body, so it goes before express.json(). */
app.post("/api/stripe/webhook", express.raw({ type: "application/json" }), (req, res) => {
  if (!stripe || !STRIPE_WEBHOOK_SECRET) return res.status(503).end();
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], STRIPE_WEBHOOK_SECRET);
  } catch {
    return res.status(400).send("Bad signature");
  }
  try {
    if (event.type === "checkout.session.completed") {
      const s = event.data.object;
      const uid = Number(s.client_reference_id);
      if (uid && s.customer) {
        q.setCustomer.run(String(s.customer), uid);
        q.setPlan.run("active", uid);
      }
    } else if (event.type === "customer.subscription.updated" || event.type === "customer.subscription.deleted") {
      const sub = event.data.object;
      const user = q.userByCustomer.get(String(sub.customer));
      if (user) q.setPlan.run(event.type.endsWith("deleted") ? "canceled" : sub.status, user.id);
    }
  } catch (err) {
    console.error("Webhook handler error:", err);
    return res.status(500).end();
  }
  res.json({ received: true });
});

app.use(express.json({ limit: "2mb" }));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });

app.get("/healthz", (_req, res) => res.json({ ok: true }));

app.post("/api/register", authLimiter, (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (!validEmail(email)) return res.status(400).json({ error: "Enter a valid email address." });
  if (password.length < 8 || password.length > 200) return res.status(400).json({ error: "Password must be at least 8 characters." });
  if (q.userByEmail.get(email)) return res.status(409).json({ error: "That email already has an account. Sign in instead." });
  const salt = crypto.randomBytes(16).toString("hex");
  const info = q.insertUser.run(email, salt, hashPassword(password, salt), Date.now());
  res.json({ token: sign({ id: info.lastInsertRowid }) });
});

app.post("/api/login", authLimiter, (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = q.userByEmail.get(email);
  if (!user || !verifyPassword(password, user.pw_salt, user.pw_hash)) {
    return res.status(401).json({ error: "Wrong email or password." });
  }
  res.json({ token: sign(user) });
});

app.get("/api/me", auth, (req, res) => {
  res.json({ email: req.user.email, pro: isPro(req.user), limits: FREE_LIMITS, billing: Boolean(stripe && STRIPE_PRICE_ID) });
});

app.delete("/api/me", auth, (req, res) => {
  q.deleteUser.run(req.user.id);
  res.json({ ok: true });
});

app.get("/api/state", auth, (req, res) => {
  const row = q.getState.get(req.user.id);
  res.json(row ? { data: JSON.parse(row.data), updatedAt: row.updated_at } : { data: null });
});

app.put("/api/state", auth, (req, res) => {
  const data = cleanState(req.body.data);
  if (!data) return res.status(400).json({ error: "Invalid data." });
  if (!isPro(req.user) && (data.mistakes.length > FREE_LIMITS.mistakes || data.cards.length > FREE_LIMITS.cards)) {
    return res.status(402).json({ error: "Free plan limit reached.", limits: FREE_LIMITS });
  }
  const now = Date.now();
  q.putState.run(req.user.id, JSON.stringify(data), now);
  res.json({ updatedAt: now });
});

app.post("/api/billing/checkout", auth, async (req, res) => {
  if (!stripe || !STRIPE_PRICE_ID) return res.status(503).json({ error: "Payments are not set up yet." });
  try {
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: STRIPE_PRICE_ID, quantity: 1 }],
      client_reference_id: String(req.user.id),
      ...(req.user.stripe_customer_id ? { customer: req.user.stripe_customer_id } : { customer_email: req.user.email }),
      success_url: `${APP_URL}/?upgraded=1`,
      cancel_url: `${APP_URL}/`,
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error("Checkout error:", err.message);
    res.status(502).json({ error: "Could not start checkout. Try again." });
  }
});

app.post("/api/billing/portal", auth, async (req, res) => {
  if (!stripe || !req.user.stripe_customer_id) return res.status(400).json({ error: "No subscription found." });
  try {
    const session = await stripe.billingPortal.sessions.create({
      customer: req.user.stripe_customer_id,
      return_url: `${APP_URL}/`,
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error("Portal error:", err.message);
    res.status(502).json({ error: "Could not open billing. Try again." });
  }
});

app.use(express.static(path.join(__dirname, "public")));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Something went wrong." });
});

app.listen(PORT, () => console.log(`MedRecall running on ${APP_URL} (port ${PORT})`));
