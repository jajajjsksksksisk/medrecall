# MedRecall

A minimal study app for medical students: log mistakes, make flashcards (notes, previous year questions, Anki/CSV), and keep a daily study streak. Spaced review is built in.

- **Frontend:** one file, `public/index.html`. Works offline and saves to the browser even without an account.
- **Backend:** `server.js` (Node + Express + SQLite). Accounts, sync across devices, Stripe subscriptions.
- **Free plan:** syncs up to 30 mistakes and 60 cards. **Pro:** unlimited. Change the numbers in `server.js` (`FREE_LIMITS`).

## Run it on your computer

1. Install Node.js 20.6 or newer.
2. In this folder:

   ```bash
   npm install
   cp .env.example .env
   ```

3. Open `.env` and set `JWT_SECRET` (the file explains how to generate one).
4. Start:

   ```bash
   npm start
   ```

5. Open http://localhost:3000. Create an account, add a card, then open the site in a second browser and sign in to check that sync works.

Payments are skipped until you add the Stripe values below.

## Turn on payments (Stripe)

1. Create a Stripe account and stay in **test mode** at first.
2. Products, then add a product with a monthly recurring price (for example $6/month). Copy the **price ID** (`price_...`) into `STRIPE_PRICE_ID`.
3. Developers, API keys: copy the secret key into `STRIPE_SECRET_KEY`.
4. Developers, Webhooks: add an endpoint `https://YOUR-SITE/api/stripe/webhook` and select these events:
   `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`.
   Copy the signing secret into `STRIPE_WEBHOOK_SECRET`.
5. For local testing, install the Stripe CLI and run:
   `stripe listen --forward-to localhost:3000/api/stripe/webhook`
   and use its secret as `STRIPE_WEBHOOK_SECRET`.
6. Test with card `4242 4242 4242 4242`. After checkout the account should show **Pro**.
7. When it all works, switch to live keys. In Stripe settings, turn on the customer portal so users can cancel themselves.

## Put it online

Any host that runs Node and keeps a disk works. Two easy options:

**Render or Railway (simplest)**
- Push this folder to a GitHub repository.
- Create a new Web Service from it. Build command `npm install`, start command `node server.js`.
- Add a persistent disk (for example mounted at `/data`) and set `DB_PATH=/data/medrecall.db`. Without a disk, accounts are lost on every deploy.
- Set the environment variables from `.env.example`, with `APP_URL` as your public address and `NODE_ENV=production`.
- Add your own domain in the host's settings. HTTPS comes with it.

**Docker**
```bash
docker build -t medrecall .
docker run -p 3000:3000 -v medrecall-data:/data --env-file .env -e DB_PATH=/data/medrecall.db medrecall
```

## Before you take real money

- Add a **Privacy Policy** and **Terms** page. You store emails and study data, and Stripe expects both.
- Back up the SQLite file regularly (copy it, or use your host's disk snapshots).
- Password reset by email is not built yet. Add it with an email service (Resend, Postmark) before many people sign up.
- Sync is "merge and keep everything". If you delete a card on one device, it can come back from another. A proper delete record is the next improvement.
- Check the rules of any exam body whose questions you let users paste in. The app only stores what each user types in for themselves. Do not ship question banks you do not own.

## Files

```
server.js        API, auth, sync, Stripe
public/index.html  the whole app
package.json     dependencies
.env.example     settings to fill in
Dockerfile       optional container build
```
